#!/bin/sh

case $0 in
/*)
   sagepath="$0"
   ;;
*)
   sagepath="$PWD/$0"
   ;;
esac

sagepath=`dirname $sagepath`
echo Changing to SageTV directory $sagepath
cd $sagepath

export LD_LIBRARY_PATH=.
java -cp MiniClient.jar:gluegen-rt.jar:jogl.all.jar:nativewindow.all.jar:. sage.miniclient.MiniClient $1 $2 > /dev/null 2>&1
#java -cp MiniClient.jar:gluegen-rt.jar:jogl.all.jar:nativewindow.all.jar:. sage.miniclient.MiniClient $1 $2 > miniclient.log 2>&1

