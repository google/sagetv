#ifndef AC3FILTER_VER_H
#define AC3FILTER_VER_H

#define AC3FILTER_VER "internal"

#endif
