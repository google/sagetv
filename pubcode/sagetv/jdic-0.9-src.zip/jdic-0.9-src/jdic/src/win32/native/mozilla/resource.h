//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MozEmbed.rc
//
#define ID_TOOLBAR_UPDATE               101
#define IDR_MAINFRAME                   128
#define IDD_PROMPT_DIALOG               128
#define IDD_PROMPT_PASSWORD_DIALOG      129
#define IDD_PROMPT_USERPASS_DIALOG      130
#define IDD_ALERT_CHECK_DIALOG          131
#define IDD_CONFIRM_CHECK_DIALOG        132
#define IDD_PROGRESS_DIALOG             133
#define IDD_CHOOSE_ACTION_DIALOG        134
#define IDD_CUSTOM_PROMPT_DIALOG        135
#define IDR_CTXMENU_DOCUMENT            140
#define IDR_CTXMENU_LINK                141
#define IDR_CTXMENU_TEXT                142
#define IDR_CTXMENU_IMAGE               143
#define IDR_CTXMENU_EDITOR              144
#define IDR_SECURITY_LOCK               150
#define IDR_SECURITY_UNLOCK             151
#define IDR_SECURITY_BROKEN             152
#define IDS_NOSECURITY_INFO             153
#define IDS_ENCRYPTION_HIGH_GRADE       154
#define IDS_ENCRYPTION_LOW_GRADE        155
#define IDS_ENCRYPTION_NONE             156
#define IDS_SRCH_STR_NOT_FOUND          157
#define IDS_VIEW_FRAME_SOURCE           158
#define IDS_OPEN_FRAME_IN_NEW_WINDOW    159
#define ID_URL_BAR                      1001
#define ID_PROG_BAR                     1002
#define IDC_PROMPT_ANSWER               2001
#define IDC_PROMPT_TEXT                 2002
#define IDC_USERNAME                    2003
#define IDC_PASSWORD                    2004
#define IDC_CHECK_SAVE_PASSWORD         2005
#define IDC_USERNAME_LABEL              2006
#define IDC_PASSWORD_LABEL              2007
#define IDC_CHECKBOX                    2008
#define IDC_MSG_TEXT                    2009
#define IDC_BTN1                        2010
#define IDC_BTN2                        2011
#define IDC_BTN3                        2012
#define IDC_ACTION                      2013
#define IDC_SAVING_FROM                 2014
#define IDC_PROGRESS                    2015
#define IDC_CONTENT_TYPE                2016
#define IDC_SAVE_TO_DISK                2017
#define IDC_OPEN_USING                  2018
#define IDC_CHOOSE_APP                  2019
#define IDC_APP_NAME                    2020
#define ID_NAV_BACK                     32773
#define ID_NAV_FORWARD                  32774
#define ID_NAV_HOME                     32775
#define ID_NAV_STOP                     32776
#define ID_NAV_RELOAD                   32777
#define ID_EDIT_SELECT_NONE             32778
#define ID_NEW_BROWSER                  32779
#define ID_VIEW_SOURCE                  32780
#define ID_VIEW_INFO                    32781
#define ID_VIEW_IMAGE                   32782
#define ID_OPEN_LINK_IN_NEW_WINDOW      32783
#define ID_SAVE_LINK_AS                 32784
#define ID_SAVE_IMAGE_AS                32785
#define ID_COPY_LINK_LOCATION           32786
#define ID_FILE_PRINTPREVIEW            32789
#define ID_FILE_PRINTSETUP              32790
#define ID_VIEW_FRAME_SOURCE            32791
#define ID_OPEN_FRAME_IN_NEW_WINDOW     32792
#define ID_ARIAL                        32805
#define ID_EDITOR_UNDO                  32813
#define ID_EDITOR_REDO                  32814

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        160
#define _APS_NEXT_COMMAND_VALUE         32815
#define _APS_NEXT_CONTROL_VALUE         1058
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
