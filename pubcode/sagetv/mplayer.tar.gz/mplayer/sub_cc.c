/*
 * sub_cc.c - Decoder for Closed Captions
 *
 * This decoder relies on MPlayer's OSD to display subtitles.
 * Be warned that the decoding is somewhat preliminary, though it basically works.
 * 
 * Most notably, only the text information is decoded as of now, discarding color,
 * background and position info (see source below).
 * 
 * by Matteo Giani
 *
 * uses source from the xine closed captions decoder
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "config.h"
#include "sub_cc.h"

#include "subreader.h"

#include "libvo/video_out.h"
#include "libvo/sub.h"


#define CC_MAX_LINE_LENGTH 64

static char chartbl[128];

static subtitle buf1,buf2;
static subtitle *fb,*bb;

static unsigned int cursor_pos=0;

/* printcc support */
static unsigned char *pcc_buffer=NULL; // one even, one odd
static unsigned char pcc_lastcode=0;
static int pcc_offset=0;

static int initialized=0;

#define CC_ROLLON 1
#define CC_ROLLUP 2

static int cc_mode=CC_ROLLON;
static int cc_lines=4; ///< number of visible rows in CC roll-up mode, not used in CC roll-on mode

#define MP_NOPTS_VALUE (-1LL<<63)
#define NTSC_CC_FIELD_1 0
#define NTSC_CC_FIELD_2 1
#define DTVCC_PACKET_DATA 2
#define DTVCC_PACKET_START = 3

typedef struct {
	int64_t pts;				// if MP_NOPTS_VALUE then packet is invalid
	unsigned char data[65 * 3]; // max number of 708 tuples is 32, multiply by two since we need both fields, and add one tuple for the 608 header
	int data_length;			// number of bytes actually used in data
} SCEA708Packet;

static int64_t cea708_max_pts = MP_NOPTS_VALUE;
static int cea708_packet_count = 0;
static SCEA708Packet cea708_packet_list[16];


static void display_buffer(subtitle * buf);

static void build_char_table(void)
{
  int i;
  /* first the normal ASCII codes */
  for (i = 0; i < 128; i++)
    chartbl[i] = (char) i;
  /* now the special codes */
  chartbl[0x2a] = 0xE1;
  chartbl[0x5c] = 0xE9;
  chartbl[0x5e] = 0xED;
  chartbl[0x5f] = 0xF3;
  chartbl[0x60] = 0xFA;
  chartbl[0x7b] = 0xE7;
  chartbl[0x7c] = 0xF7;
  chartbl[0x7d] = 0xD1;
  chartbl[0x7e] = 0xF1;
  chartbl[0x7f] = 0xA4;    /* FIXME: this should be a solid block */
}

static void clear_buffer(subtitle *buf)
{
	int i;
	buf->lines=0;
	for(i=0;i<SUB_MAX_TEXT;i++) if(buf->text[i]) {free(buf->text[i]);buf->text[i]=NULL;}
}


/**
 \brief scroll buffer one line up
 \param buf buffer to scroll
*/
static void scroll_buffer(subtitle* buf)
{
	int i;

	while(buf->lines > cc_lines)
	{
		if(buf->text[0]) free(buf->text[0]);

		for(i = 0; i < (buf->lines - 1); i++) buf->text[i] = buf->text[i+1];

		buf->text[buf->lines-1] = NULL;
		buf->lines--;
	}
}
 
 
void subcc_init(void)
{
	int i;
	//printf("subcc_init(): initing...\n");
	build_char_table();
	for(i=0;i<SUB_MAX_TEXT;i++) {buf1.text[i]=buf2.text[i]=NULL;}
	buf1.lines=buf2.lines=0;
	fb=&buf1;
	bb=&buf2;
	
	if (!pcc_buffer)
		pcc_buffer = malloc(256);
	pcc_lastcode = 0;
	pcc_offset = 0;
	
	cea708_max_pts = MP_NOPTS_VALUE;
	cea708_packet_count = 0;
	for (i=0; i < 16; i++) {
		cea708_packet_list[i].pts = MP_NOPTS_VALUE;
		cea708_packet_list[i].data_length = 0;
	}
	
	initialized=1;
}

static void append_char(char c)
{
	if(!bb->lines) {bb->lines++; cursor_pos=0;}
	if(bb->text[bb->lines - 1]==NULL) 
	{
		bb->text[bb->lines - 1]=malloc(CC_MAX_LINE_LENGTH);
		memset(bb->text[bb->lines - 1],0,CC_MAX_LINE_LENGTH);
		cursor_pos=0;
	}
	
	if(c=='\n')
	{
		if(cursor_pos>0 && bb->lines < SUB_MAX_TEXT)
		{
			bb->lines++;cursor_pos=0;
			if(cc_mode==CC_ROLLUP){ //Carriage return - scroll buffer one line up
				bb->text[bb->lines - 1]=calloc(1, CC_MAX_LINE_LENGTH);
				scroll_buffer(bb);
			}
		}
	}
	else 
	{
		if(cursor_pos==CC_MAX_LINE_LENGTH-1)
		{
			fprintf(stderr,"sub_cc.c: append_char() reached CC_MAX_LINE_LENGTH!\n");
			return;
		}
		bb->text[bb->lines - 1][cursor_pos++]=c;
	}
	//In CC roll-up mode data should be shown immediately
	if(cc_mode==CC_ROLLUP) display_buffer(bb);
}


static void swap_buffers(void)
{
	subtitle *foo;
	foo=fb;
	fb=bb;
	bb=foo;
}

static void display_buffer(subtitle * buf)
{
	vo_sub=buf;
	vo_osd_changed(OSDTYPE_SUBTITLE);
}

static void dump_pcc_buffer()
{
	int ii;
	
	if (!pcc_buffer)
		return;
	if (!pcc_offset)
		return;
	
	printf("CCDATA:");
	for (ii = 0; ii < pcc_offset; ii++)
		printf(" %02x", pcc_buffer[ii]);
	fputc('\n', stdout);
	fflush(stdout);
	
	pcc_offset = 0;
}

static void append_pcc_buffer(unsigned char v1, unsigned char v2)
{
	int dump = 0;
	
	// dump if we're about to overflow the buffer
	if (pcc_offset + 2 >= 254)
		dump_pcc_buffer();
	
	if (v1 == 0x80 && v2 == 0x80) return; // no data
	if (v1 == 0x94) {
		// skip repeated codes
		if (v2 == pcc_lastcode) {
			pcc_lastcode = 0;
			return;
		}
		pcc_lastcode = v2;
		// dump on the following control codes
		if(v2 == 0x2c || v2 == 0x2d || v2 == 0x2e || v2 == 0x2f)
			dump = 1;
	}
	
	pcc_buffer[pcc_offset++] = v1;
	pcc_buffer[pcc_offset++] = v2;
	
	if (dump)
		dump_pcc_buffer();
}

static void cc_decode_EIA608(unsigned short int data)
{
  
  static unsigned short int lastcode=0x0000;	
  unsigned char c1 = data & 0x7f;
  unsigned char c2 = (data >> 8) & 0x7f;

  if (c1 & 0x60) {		/* normal character, 0x20 <= c1 <= 0x7f */
	   append_char(chartbl[c1]);
	   if(c2 & 0x60)	/*c2 might not be a normal char even if c1 is*/
		   append_char(chartbl[c2]);
  }
  else if (c1 & 0x10)		// control code / special char
  {
//	  int channel= (c1 & 0x08) >> 3;
	  c1&=~0x08;
	  if(data!=lastcode)
	  {
	  	if(c2 & 0x40) {	/*PAC, Preamble Address Code */
			append_char('\n'); /*FIXME properly interpret PACs*/
		}
		else
			switch(c1)
			{
				case 0x10:	break; // ext attribute
				case 0x11: 
					if((c2 & 0x30)==0x30) 
					{
						//printf("[debug]:Special char (ignored)\n");
						/*cc_decode_special_char()*/;
					}
					else if (c2 & 0x20) 
					{
						//printf("[debug]: midrow_attr (ignored)\n");
						/*cc_decode_midrow_attr()*/;
					}
					break;
				case 0x14:
					switch(c2)
					{
						case 0x00: //CC roll-on mode
							   cc_mode=CC_ROLLON;
							   break;
						case 0x25: //CC roll-up, 2 rows
						case 0x26: //CC roll-up, 3 rows
						case 0x27: //CC roll-up, 4 rows
							   cc_lines=c2-0x23;
							   cc_mode=CC_ROLLUP;
							   break;
						case 0x2C: display_buffer(NULL); //EDM
							   clear_buffer(fb); break;
						case 0x2d: append_char('\n');	//carriage return
							   break;
						case 0x2e: clear_buffer(bb);	//ENM
							   break;
						case 0x2f: swap_buffers();	//Swap buffers
							   display_buffer(fb);
							   clear_buffer(bb);
							   break;
					}
					break;
				case 0x17:
					if( c2>=0x21 && c2<=0x23) //TAB
					{
						break;
					}
			}
	  }
  } 
  lastcode=data;  
}

static void subcc_decode(unsigned char *inputbuffer, unsigned int inputlength)
{
  /* The first number may denote a channel number. I don't have the
   * EIA-708 standard, so it is hard to say.
   * From what I could figure out so far, the general format seems to be:
   *
   * repeat
   *
   *   0xfe starts 2 byte sequence of unknown purpose. It might denote
   *        field #2 in line 21 of the VBI. We'll ignore it for the
   *        time being.
   *
   *   0xff starts 2 byte EIA-608 sequence, field #1 in line 21 of the VBI.
   *        Followed by a 3-code triplet that starts either with 0xff or
   *        0xfe. In either case, the following triplet needs to be ignored
   *        for line 21, field 1.
   *
   *   0x00 is padding, followed by 2 more 0x00.
   *
   *   0x01 always seems to appear at the beginning, always seems to
   *        be followed by 0xf8, 8-bit number. 
   *        The lower 7 bits of this 8-bit number seem to denote the
   *        number of code triplets that follow.
   *        The most significant bit denotes whether the Line 21 field 1 
   *        captioning information is at odd or even triplet offsets from this
   *        beginning triplet. 1 denotes odd offsets, 0 denotes even offsets.
   *      
   *        Most captions are encoded with odd offsets, so this is what we
   *        will assume.
   *
   * until end of packet
   */
  unsigned char *current = inputbuffer;
  unsigned int curbytes = 0;
  unsigned char data1, data2;
  unsigned char cc_code;
  int odd_offset = 1;

  while (curbytes < inputlength) {
    int skip = 2;

    cc_code = *(current);

    if (inputlength - curbytes < 2) {
#ifdef LOG_DEBUG
      fprintf(stderr, "Not enough data for 2-byte CC encoding\n");
#endif
      break;
    }
    
    data1 = *(current+1);
    data2 = *(current + 2);
    current++; curbytes++;
    
    switch (cc_code) {
    case 0xfe:
      /* expect 2 byte encoding (perhaps CC3, CC4?) */
      /* ignore for time being */
      skip = 2;
      break;
      
    case 0xff:
      /* expect EIA-608 CC1/CC2 encoding */
      // FIXME check parity!
      // Parity check omitted assuming we are reading from a DVD and therefore
      // we should encounter no "transmission errors".
      if (subcc_printccdata)
      	append_pcc_buffer((unsigned char)data1, (unsigned char)data2);
      else
      	cc_decode_EIA608(data1 | (data2 << 8));
      
      skip = 5;
      break;
      
    case 0x00:
      /* This seems to be just padding */
      skip = 2;
      break;
      
    case 0x01:
      odd_offset = data2 & 0x80;
      if (odd_offset)
	skip = 2;
      else
	skip = 5;
      break;
      
    default:
//#ifdef LOG_DEBUG
      fprintf(stderr, "Unknown CC encoding: %x\n", cc_code);
//#endif
      skip = 2;
      break;
    }
    current += skip;
    curbytes += skip;
  }
}

void subcc_set_enabled(int state)
{
	subcc_enabled = state;
	if (!subcc_enabled) {
		// clear current OSD
		display_buffer(NULL);
		clear_buffer(fb);
		clear_buffer(bb);
	}
}

// clear OSD and all CEA708 packets
void subcc_reset()
{
	int ii;
	
	if (!subcc_enabled) return;
	if (!initialized) subcc_init();
	
	// clear current OSD
	display_buffer(NULL);
	clear_buffer(fb);
	clear_buffer(bb);
	
	cea708_max_pts = MP_NOPTS_VALUE;
	cea708_packet_count = 0;
	for (ii=0; ii < 16; ii++) {
		cea708_packet_list[ii].pts = MP_NOPTS_VALUE;
		cea708_packet_list[ii].data_length = 0;
	}
}

void subcc_process_data(unsigned char *inputdata,unsigned int len)
{
	if(!subcc_enabled) return;
	if(!initialized) subcc_init();
	
	subcc_decode(inputdata, len);
}

// extract CEA-608 data encapsulated in CEA-708 user data
// ignores other data for now
/*
	CEA-708-B data is encoded in frame order, so if we just spit out the data as it comes in, the codes will (most likely) be out of order.
	We'll account for this by tracking the last highest PTS and holding off on processing buffers until we get a PTS that's higher than
	the current highest, then run through all the buffers we've accumulated. Hopefully this won't be too ugly...
 */
//#define DUMP_CC
#ifdef DUMP_CC
 #define DCC(...) fprintf(stderr, __VA_ARGS__)
#else
 #define DCC(...) do{}while(0)
#endif

// returns number of tuples stored in the packet, zero if no valid/usable data was found
static int build_CEA708_packet(SCEA708Packet *pkt, int cc_count, unsigned char *buffer, int len, int64_t pts)
{
	int tupleCount = 0, ii;
	
	// build the 608 header for subcc_decode
	pkt->data[0] = 0x01;
	pkt->data[1] = 0xf8;
	pkt->data[2] = 0; // number of valid tuples
	pkt->data_length = 3;
	
	DCC("\npts = %lld, cc_count = %d:", pts, cc_count);
	for (ii = 0; ii < cc_count; ii++) {
		if ((buffer[0] & 0xfc) == 0xfc) { // check both marker bits AND cc_valid flag
			// cc_type values: NTSC_CC_FIELD_1 = 0, NTSC_CC_FIELD_2 = 1, DTVCC_PACKET_DATA = 2, DTVCC_PACKET_START = 3
			unsigned char cc_type = buffer[0] & 0x03;
			
			// only care about NTSC_CC_FIELD_1 data for now
			if (cc_type == NTSC_CC_FIELD_1) {
				DCC(" %02x:%02x%02x (%c%c)", buffer[ii*3], buffer[ii*3+1], buffer[ii*3+2], buffer[ii*3+1], buffer[ii*3+2]);
				
				pkt->data[pkt->data_length++] = 0xff;
				pkt->data[pkt->data_length++] = buffer[1];
				pkt->data[pkt->data_length++] = buffer[2];
				// even field data, since subcc_decode expects it
				pkt->data[pkt->data_length++] = 0xff;
				pkt->data[pkt->data_length++] = 0x80;
				pkt->data[pkt->data_length++] = 0x80;
				pkt->data[2] += 2;
				tupleCount++;
			}
		}
		buffer += 3;
	}
	DCC("\n");
	
	if (tupleCount) {
		pkt->pts = pts;
		pkt->data[2] |= 0x80; // starts with odd field
		// pkt->data_length already set
		cea708_packet_count++;
		if (cea708_max_pts == MP_NOPTS_VALUE || pts > cea708_max_pts)
			cea708_max_pts = pts;
	} else {
		pkt->pts = MP_NOPTS_VALUE;
		pkt->data_length = 0;
	}
	
	return tupleCount;
}

void subcc_process_CEA708_data(unsigned char *inputdata, unsigned int len, int64_t pts)
{
	int ii, cc_count = 0;
	
	if(!subcc_enabled) return;
	if(!initialized) subcc_init();
	
	// bail if not CC data
	if (inputdata[4] != 0x03) return;
	
	// we get the full user data packet here, so skip the GA94 and type, they've already been processed
	inputdata += 5;
	len -= 5;
	if (len < 2) return;
	
	// check process_cc_data_flag, if not set then discard the entire packet
	if ((inputdata[0] & 0x40) != 0x40)
		return;
	
	cc_count = inputdata[0] & 0x1f;
	
	inputdata += 2;
	len -= 2;
	
	// len should be at least cc_count * 3 + 1, but could be longer if there's additional data
	// adjust cc_count if len is short so we don't overrun the buffer
	if (len < (cc_count * 3 + 1)) {
		fprintf(stderr, "\nAdjusting cc_count to avoid buffer overflow!\n");
		cc_count = len / 3; // FIXME: skip last marker byte?
	}
	
	if (cc_count) {
		// first, if the new pts > max pts, then dump the current list
		if (cea708_packet_count && (cea708_max_pts != MP_NOPTS_VALUE) && (pts > cea708_max_pts)) {
			do {
				int64_t lowPTS = MP_NOPTS_VALUE;
				int lowIndex = -1;
				
				for (ii=0; ii < 16; ii++) {
					if (cea708_packet_list[ii].pts != MP_NOPTS_VALUE) {
						if (lowPTS == MP_NOPTS_VALUE || (lowPTS > cea708_packet_list[ii].pts)) {
							lowPTS = cea708_packet_list[ii].pts;
							lowIndex = ii;
						}
					}
				}
				
				if (lowIndex != -1) {
					SCEA708Packet *pkt = &cea708_packet_list[lowIndex];
#ifdef DUMP_CC
					fprintf(stderr, "\npts = %lld, length = %d:", pkt->pts, pkt->data[2] & 0x7F);
					for (ii = 1; ii < (int)(pkt->data[2] & 0x7F) + 1; ii++) {
						fprintf(stderr, " %02x:%02x%02x (%c%c)", pkt->data[ii*3], pkt->data[ii*3+1], pkt->data[ii*3+2], pkt->data[ii*3+1], pkt->data[ii*3+2]);
					}
					fprintf(stderr, "\n");
#endif
					subcc_decode(pkt->data, pkt->data_length);
					pkt->data_length = 0;
					pkt->pts = MP_NOPTS_VALUE;
				}
			} while (--cea708_packet_count);
		}
		
		// valid packet with data, get the next unused 708 packet and fill it in
		for (ii=0; ii < 16; ii++) {
			if (cea708_packet_list[ii].pts == MP_NOPTS_VALUE) {
				if (build_CEA708_packet(&cea708_packet_list[ii], cc_count, inputdata, len, pts) != 0) {
					if (cea708_max_pts == MP_NOPTS_VALUE)
						cea708_max_pts = pts;
				}
				break;
			}
		}
		// FIXME: handle packet count > 16?
	}
}
