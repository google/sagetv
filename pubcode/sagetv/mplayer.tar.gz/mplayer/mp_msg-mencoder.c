
#define FOR_MENCODER 1
#include "mp_msg.c"
