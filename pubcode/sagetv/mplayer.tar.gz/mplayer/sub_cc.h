#ifndef MPLAYER_SUB_CC_H
#define MPLAYER_SUB_CC_H

#include <stdint.h>

extern int subcc_enabled;
extern int subcc_printccdata;

void subcc_init(void);
void subcc_set_enabled(int state); // clears current OSD on disable
void subcc_reset(void); // clears current closed captioning data and display
void subcc_process_data(unsigned char *inputdata,unsigned int len);
void subcc_process_CEA708_data(unsigned char *inputdata, unsigned int len, int64_t pts);

#endif /* MPLAYER_SUB_CC_H */
