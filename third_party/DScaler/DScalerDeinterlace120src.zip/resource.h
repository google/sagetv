//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Deinterlace.rc
//
#define VERSION_RES_MINOR_VER           0
#define VERSION_RES_BUILD               0
#define VER_DEBUG                       0
#define VERSION_RES_MAJOR_VER           1
#define IDD_DEINTERLACEPROP             101
#define IDD_DEINTERLACEABOUT            102
#define IDD_DIALOG1                     103
#define IDC_CURSOR1                     104
#define IDI_ICON1                       105
#define IDC_DEINTERLACE                 1000
#define IDB_DEFAULT                     1001
#define IDS_TITLE                       1015
#define IDS_ABOUT                       1016
#define IDC_WEAVE                       1020
#define IDC_BOB                         1021
#define IDC_TYPE1                       1022
#define IDC_TYPE2                       1023
#define IDC_TYPE3                       1024
#define IDC_TYPE4                       1025
#define IDC_ODDFIELDFIRST               1027
#define IDC_PLUGINS                     1028
#define VERSION_RES_LANGUAGE            0x409
#define VERSION_RES_CHARSET             1252
#define IDS_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
