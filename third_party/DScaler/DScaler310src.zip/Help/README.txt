To compile the help file you will need to install the Help workshop.


http://msdn.microsoft.com/library/tools/htmlhelp/wkshp/download.htm