To create the install file you will need to install the Visual Studio Installer 1.1


http://msdn.microsoft.com/vstudio/downloads/vsi11/download.asp