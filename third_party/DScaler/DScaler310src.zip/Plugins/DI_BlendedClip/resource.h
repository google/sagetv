//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DI_BlendedClip.RC
//
#define IDC_DEFAULT                     1774
#define IDC_MIN_CLIP                    1790
#define IDC_PIXEL_MOV                   1791
#define IDC_MIN_CLIP_V                  1792
#define IDC_PIXEL_MOV_V                 1795
#define IDC_AVG_MOV                     1796
#define IDC_AVG_MOV_V                   1797
#define IDC_MOV_PERIOD                  1798
#define IDC_MOV_PERIOD_V                1799
#define IDC_PIXEL_COMB                  1800
#define IDC_PIXEL_COMB_V                1801
#define IDC_AVG_COMB                    1802
#define IDC_AVG_COMB_V                  1803
#define IDC_COMB_PERIOD                 1804
#define IDC_COMB_PERIOD_V               1805
#define IDC_COMB_SKIP                   1806
#define IDC_COMB_SKIP_V                 1807
#define IDC_MOTION_SKIP                 1808
#define IDC_MOTION_SKIP_V               1809
#define IDC_USE_INTERP_BOB              1810
#define IDC_BLEND_CHROMA                1811
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        160
#define _APS_NEXT_COMMAND_VALUE         816
#define _APS_NEXT_CONTROL_VALUE         1879
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
